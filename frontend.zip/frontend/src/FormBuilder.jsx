import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

export default function FormBuilder() {
  const { id } = useParams();
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const [form, setForm] = useState({
    title: "Untitled Form",
    description: "",
    questions: [],
    isPublished: false,
  });

  useEffect(() => {
    axios
      .get(`http://localhost:5000/forms/${id}`)
      .then((res) => setForm(res.data))
      .catch(() => {});
  }, [id]);

  const addQuestion = () => {
    setForm({
      ...form,
      questions: [
        ...form.questions,
        {
          title: "Untitled Question",
          type: "short",
          required: false,
          options: ["Option 1"],
        },
      ],
    });
  };

  const updateQuestion = (index, updated) => {
    const updatedQuestions = [...form.questions];
    updatedQuestions[index] = {
      ...updatedQuestions[index],
      ...updated,
    };
    setForm({ ...form, questions: updatedQuestions });
  };

  const saveForm = async () => {
    await axios.put(
      `http://localhost:5000/forms/${id}`,
      form,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    alert("Form Saved");
  };

  const publishForm = async () => {
    await axios.post(
      `http://localhost:5000/forms/${id}/publish`,
      {},
      { headers: { Authorization: `Bearer ${token}` } }
    );
    setForm({ ...form, isPublished: true });
    alert("Form Published!");
  };

  return (
    <div className="min-h-screen bg-gray-100">

      {/* Header */}
      <div className="bg-purple-600 text-white p-4 flex justify-between">
        <h1>Edit Form</h1>

        <div className="flex gap-3">
          <button
            onClick={saveForm}
            className="bg-blue-600 px-4 py-1 rounded"
          >
            Save
          </button>

          <button
            onClick={publishForm}
            className="bg-green-600 px-4 py-1 rounded"
          >
            Publish
          </button>

          <button
            onClick={() => navigate("/")}
            className="bg-white text-purple-600 px-4 py-1 rounded"
          >
            Back
          </button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto p-6">

        {/* Title */}
        <div className="bg-white p-6 rounded-xl shadow mb-6">
          <input
            value={form.title}
            onChange={(e) =>
              setForm({ ...form, title: e.target.value })
            }
            className="text-3xl font-semibold w-full outline-none mb-2"
          />

          <input
            value={form.description}
            onChange={(e) =>
              setForm({ ...form, description: e.target.value })
            }
            placeholder="Form description"
            className="w-full outline-none text-gray-500"
          />
        </div>

        {/* Questions */}
        {form.questions.map((q, index) => (
          <div
            key={index}
            className="bg-white p-6 rounded-xl shadow mb-6 border-l-4 border-purple-600"
          >
            <input
              value={q.title}
              onChange={(e) =>
                updateQuestion(index, { title: e.target.value })
              }
              className="w-full text-lg outline-none mb-4"
            />

            <div className="flex justify-between mb-4">
              <select
                value={q.type}
                onChange={(e) =>
                  updateQuestion(index, { type: e.target.value })
                }
                className="border px-2 py-1 rounded"
              >
                <option value="short">Short Answer</option>
                <option value="paragraph">Paragraph</option>
                <option value="mcq">Multiple Choice</option>
                <option value="yesno">Yes / No</option>
              </select>

              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={q.required}
                  onChange={() =>
                    updateQuestion(index, {
                      required: !q.required,
                    })
                  }
                />
                Required
              </label>
            </div>

            {q.type === "mcq" &&
              q.options.map((opt, i) => (
                <div key={i} className="flex gap-2 mb-2">
                  <input type="radio" disabled />
                  <input
                    value={opt}
                    onChange={(e) => {
                      const newOptions = [...q.options];
                      newOptions[i] = e.target.value;
                      updateQuestion(index, {
                        options: newOptions,
                      });
                    }}
                    className="border-b flex-1 outline-none"
                  />
                </div>
              ))}

            {q.type === "mcq" && (
              <button
                onClick={() =>
                  updateQuestion(index, {
                    options: [...q.options, "New Option"],
                  })
                }
                className="text-purple-600 text-sm"
              >
                + Add option
              </button>
            )}
          </div>
        ))}

        <button
          onClick={addQuestion}
          className="bg-purple-600 text-white px-4 py-2 rounded"
        >
          Add Question
        </button>

        {form.isPublished && (
          <div className="mt-6 bg-green-100 p-4 rounded">
            Public Link:
            <div className="font-mono">
              http://localhost:5173/public/{id}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}