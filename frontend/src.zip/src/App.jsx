import { Routes, Route } from "react-router-dom";
import Dashboard from "./Dashboard";
import FormBuilder from "./FormBuilder";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/form/:id" element={<FormBuilder />} />
    </Routes>
  );
}

export default App;
