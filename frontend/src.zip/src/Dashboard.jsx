import { useNavigate } from "react-router-dom";

function Dashboard() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#f8f9fa]">

      {/* Navbar */}
      <div className="bg-white shadow-sm px-6 py-3 flex items-center justify-between">

        <div className="flex items-center gap-3">
          <div className="bg-purple-600 text-white w-8 h-8 flex items-center justify-center rounded">
            📄
          </div>
          <span className="text-xl font-medium">Forms</span>
        </div>

        <input
          placeholder="Search"
          className="bg-gray-100 px-4 py-2 rounded-full w-1/3 outline-none"
        />

        <div className="w-8 h-8 bg-green-600 rounded-full"></div>

      </div>

      <div className="max-w-6xl mx-auto py-8 px-6">

        {/* Start New Form */}
        <div>
          <h2 className="text-lg font-medium mb-4">
            Start a new form
          </h2>

          <div className="flex gap-6">

            {/* Blank Form */}
            <div
              onClick={() => navigate(`/form/${Date.now()}`)}
              className="cursor-pointer"
            >
              <div className="w-40 h-52 bg-white shadow rounded-lg flex items-center justify-center text-5xl hover:shadow-lg transition">
                +
              </div>
              <p className="mt-2 text-sm">Blank form</p>
            </div>

          </div>
        </div>

        {/* Recent Forms Placeholder */}
        <div className="mt-12">
          <h2 className="text-lg font-medium mb-6">
            Recent forms
          </h2>

          <div className="grid grid-cols-4 gap-6">
            <div className="bg-white shadow rounded-lg h-56 hover:shadow-lg transition cursor-pointer"></div>
            <div className="bg-white shadow rounded-lg h-56 hover:shadow-lg transition cursor-pointer"></div>
            <div className="bg-white shadow rounded-lg h-56 hover:shadow-lg transition cursor-pointer"></div>
            <div className="bg-white shadow rounded-lg h-56 hover:shadow-lg transition cursor-pointer"></div>
          </div>

        </div>

      </div>
    </div>
  );
}

export default Dashboard;
